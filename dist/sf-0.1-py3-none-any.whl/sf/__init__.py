def hello_word():
    print("hello world")